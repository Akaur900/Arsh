document.addEventListener('DOMContentLoaded', function() {
    const hobbiesHeading = document.querySelector('h1');
    hobbiesHeading.addEventListener('click', function() {
        alert('Enjoy your hobbies!');
    });
});